const dummydata = [
    {
        id:1,
        heading:'Heading 1',
        about : [
            "Invest ",
            "Metaverse"
        ],
        members:'1'
    },
    {
        id:2,
        heading:'Heading 2',
        about : [
            "Invest ",
            "Metaverse"
        ],
        members:'2'
    },
    {
        id:3,
        heading:'Heading 3',
        about : [
            "Invest ",
            "Metaverse"
        ],
        members:'3'
    },
    {
        id:4,
        heading:'Heading 4',
        about : [
            "Invest ",
            "Metaverse"
        ],
        members:'4'
    },
    {
        id:5,
        heading:'Heading 5',
        about : [
            "Invest ",
            "Metaverse"
        ],
        members:'5'
    }
    
    ,
    {
        id:6,
        heading:'Heading 5',
        about : [
            "Invest ",
            "Metaverse"
        ],
        members:'5'
    }
    
    

    
]


export default dummydata;